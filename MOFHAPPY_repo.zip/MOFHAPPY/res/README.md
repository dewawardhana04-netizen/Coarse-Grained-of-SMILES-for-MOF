Letakkan gambar hasil di sini (mis. parity plot, bar chart perbandingan), lalu rujuk dari README dengan ![](res/nama.png)
